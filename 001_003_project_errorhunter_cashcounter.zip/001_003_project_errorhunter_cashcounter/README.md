# CashCounter

Hier ist ein Beispiel für eine einfache Kassensoftware, die in der Konsole läuft. In diesem Code sind verschiedene
Fehler eingebaut, die während der Laufzeit auftreten können. Diese Fehler sind sowohl logischer Art, erfordern aber
gute Kenntnisse über das Java-Ökosystem.



**Leichte Fehler:**

1. Die Gesamtsumme sollte null sein, wenn das Programm startet – gibt es Situationen, in denen das nicht der Fall ist?
2. Es wird angenommen, dass der Benutzer korrekte Produktcodes eingibt. Wie wird mit Fehleingaben umgegangen?

**Mittelschwere Fehler:**

1. Die Behandlung der Eingabeaufforderung ist anfällig für unerwartete Eingaben. Was passiert, wenn ein Benutzer
   ungewöhnliche Eingaben macht?
2. Es wird angenommen, dass der Benutzer nur einmal für ein Produkt bezahlt. Gibt es eine Möglichkeit, die Anzahl der
   gekauften Produkte zu berücksichtigen?

**Schwere Fehler:**

1. Es wird ein HashMap verwendet, um Produktcodes und Preise zu speichern. Sind die Schlüssel robust gegenüber
   unterschiedlichen Eingabeformaten?
2. Was passiert, wenn ein Null-Pointer-Exception oder eine andere Ausnahme auftritt? Sind diese angemessen behandelt?
