package schwarz.it.lws.cashcounter;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CashCounterApp {

    private static Map<String, Double> produktPreise = new HashMap<>();
    private static double gesamtSumme = 0;

    static {
        produktPreise.put("Apfel", 0.50);
        produktPreise.put("Brot", 1.99);
        produktPreise.put("Milch", 0.99);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String eingabe;

        System.out.println("KASSENSOFTWARE\n");

        do {
            System.out.println("Bitte Produktcode eingeben (fertig = Beenden): ");
            eingabe = scanner.nextLine();
            processProduct(eingabe);
        } while (!eingabe.equalsIgnoreCase("fertig"));

        System.out.printf("Die Gesamtsumme beträgt: %.2f€\n", gesamtSumme);
        scanner.close();
    }

    private static void processProduct(String produkt) {
        if (produktPreise.containsKey(produkt)) {
            gesamtSumme += produktPreise.get(produkt);
            System.out.printf("Produkt hinzugefügt: %s, Preis: %.2f€\n", produkt, produktPreise.get(produkt));
        } else if (!produkt.equals("fertig")) {
            System.out.println("Produkt nicht gefunden.");
        }
    }
}