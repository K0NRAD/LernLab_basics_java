package schwarz.it.lws.carparkingmanagement;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CarParkManagement {

    private static final Map<String, Parkticket> parkTickets = new HashMap<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Parkplatz-Verwaltungssystem mit Schranke und Bezahlautomat");

        while (true) {
            System.out.println("Bitte wählen Sie eine Option: (1) Ticket ziehen, (2) Bezahlen, (3) Schranke passieren, (4) Beenden");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    pullTicket();
                    break;
                case "2":
                    pay();
                    break;
                case "3":
                    passBarrier();
                    break;
                case "4":
                    System.out.println("System wird beendet...");
                    return;
                default:
                    System.out.println("Ungültige Eingabe. Bitte wählen Sie 1, 2, 3 oder 4.");
                    break;
            }
        }
    }

    private static void pullTicket() {
        System.out.println("Geben Sie das Kennzeichen des Fahrzeugs ein:");
        String licencePlate = scanner.nextLine();
        Parkticket ticket = new Parkticket(licencePlate, System.currentTimeMillis(), false);
        parkTickets.put(licencePlate, ticket);
        System.out.println("Ticket für Fahrzeug " + licencePlate + " wurde erstellt.");
    }

    private static void pay() {
        System.out.println("Geben Sie das Kennzeichen des Fahrzeugs ein, um zu bezahlen:");
        String licencePlate = scanner.nextLine();
        Parkticket ticket = parkTickets.get(licencePlate);

        if (ticket == null) {
            System.out.println("Kein Ticket für dieses Kennzeichen gefunden.");
            return;
        }

        long parkingDuration = System.currentTimeMillis() - ticket.getArrivalTime();
        double fee = calculateFee(parkingDuration);
        ticket.setPayed(true);
        System.out.println("Fahrzeug " + licencePlate + " hat bezahlt. Parkgebühren: " + fee + " Euro.");
    }

    private static void passBarrier() {
        System.out.println("Geben Sie das Kennzeichen des Fahrzeugs ein, das die Schranke passieren möchte:");
        String licencePlate = scanner.nextLine();
        Parkticket ticket = parkTickets.get(licencePlate);

        if (ticket == null || !ticket.isPayed()) {
            System.out.println("Fahrzeug kann die Schranke nicht passieren. Ticket nicht bezahlt oder nicht vorhanden.");
            return;
        }

        parkTickets.remove(licencePlate);
        System.out.println("Die Schranke wurde für Fahrzeug " + licencePlate + " geöffnet.");
    }

    private static double calculateFee(long parkingDuration) {
        // Fehler könnte hier sein: Parkdauer sollte in Stunden umgerechnet werden, um die Gebühren zu berechnen.
        double hours = parkingDuration / 3600000.0;
        return 2.0 * Math.ceil(hours); // Tarif: 2 Euro pro angefangene Stunde, aufgerundet
    }

    static class Parkticket {
        private String licencePlate;
        private long arrivalTime;
        private boolean payed;

        public Parkticket(String licencePlate, long arrivalTime, boolean payed) {
            this.licencePlate = licencePlate;
            this.arrivalTime = arrivalTime;
            this.payed = payed;
        }

        public String getLicencePlate() {
            return licencePlate;
        }

        public long getArrivalTime() {
            return arrivalTime;
        }

        public boolean isPayed() {
            return payed;
        }

        public void setPayed(boolean payed) {
            this.payed = payed;
        }
    }
}