# Car park management

Dieses Projekt ist ein Parkplatz Verwaltungssystem mit einer Schranke, einem Bezahlautomaten und Parktickets.
Auch hier können verschiedene Fehler eingebaut sein, die es identifizieren und korrigieren gilt.


### Fehler zum Entdecken:

**Leichte Fehler:**
1. Was passiert, wenn ein Fahrzeug bezahlt und dann mehr Zeit auf dem Parkplatz verbringt, bevor es die Schranke passiert?
2. Wie wird mit dem Ticket umgegangen, nachdem ein Fahrzeug die Schranke passiert hat?

**Mittelschwere Fehler:**
1. Wie genau ist die Zeitmessung, und wie werden Rundungen bei der Berechnung der Gebühren gehandhabt?
2. Wie wird sichergestellt, dass das Ticket nach der Bezahlung nur für eine bestimmte Zeit gültig ist?

**Schwere Fehler:**
1. Wie wird die Situation gehandhabt, wenn der Parkplatz voll ist?
2. Wie verhält sich das System, wenn zwei Fahrzeuge das gleiche Kennzeichen haben (z.B. durch einen Eingabefehler)?
